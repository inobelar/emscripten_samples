/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

/*___Generated_by_IDEA___*/

package com.facebook.yoga;

/* This stub is only used by the IDE. It is NOT the BuildConfig class actually packed into the APK */
public final class BuildConfig {
  public final static boolean DEBUG = Boolean.parseBoolean(null);
}