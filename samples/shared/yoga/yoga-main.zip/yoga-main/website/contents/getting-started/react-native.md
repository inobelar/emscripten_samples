---
path: "https://reactnative.dev/docs/getting-started"
title: "React Native"
redirect: true
---
